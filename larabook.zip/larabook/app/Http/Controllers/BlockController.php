<?php

namespace App\Http\Controllers;
use App\Models\Block;
use App\Models\Topic;

use Illuminate\Http\Request;

class BlockController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $block=new Block;
        $topics=Topic::pluck('topicname', 'id');
        return view('block.create', ['block'=>$block, 'topics'=>$topics, 'page'=>'AddBlock']);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validated= $request->validate([
            'topicid' => 'required|exists:topics,id',
            'title' => 'required|string|max:255',
            'content' => 'string|required',
            'imagepath' => 'nullable|image|mimes:jpg,jpeg,png,gif|max:2048'
        ]);

        $block = new Block();
        $block->topicid = $validated['topicid'];
        $block->title=$validated['title'];
        $block->content=$validated['content'];

        if($request->hasFile('imagepath')){
            $path=$request->file('imagepath')->store('images','public');
            $block->imagepath= $path;
        }

        $block->save();

        return redirect()
            ->route('block.create')
            ->with('success',"Блок '{$block->title}' успешно добавлен!");
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $block=Block::find($id);
        $topics=Topic::pluck('topicname', 'id');
        return view('block.edit') ->with('block',$block)->with('topics',$topics)->with('page',"Main Page");
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $block=Block::find($id);
        $block -> delete();
        return redirect('topic');
    }
}
