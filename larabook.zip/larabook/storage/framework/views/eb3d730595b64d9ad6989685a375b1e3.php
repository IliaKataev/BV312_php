

<?php $__env->startSection('menu'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('menu'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <div class="row">
        
        <div class="col-sm-3 col-md-3 col-lg-3">
            <ul class="list-unstyled">
                <?php $__currentLoopData = $topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="mb-2">
                        <a href="<?php echo e(url('topic/' . $t->id)); ?>" class="text-decoration-none">
                            <?php echo e($t -> topicname); ?>

                        </a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        
        <div class="col-sm-9 col-md-9 col-lg-9">
            <?php if($id != 0): ?>
                <?php $__currentLoopData = $blocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card shadow-sm mb-4">
                        <div class="card-body">
                            <h4 class="card-title"> <?php echo e($b -> title); ?></h4>
                            <?php if(!empty($b->imagepath)): ?>
                                <a href="<?php echo e(asset('storage/'.$b->imagepath)); ?>" target="_blank" class="d-inline-block mb-2 me-3">
                                    <img src="<?php echo e(asset('storage/'. $b->imagepath)); ?>" alt="Image" class="img-fluid rounded" style="max-height: 150px" >
                                </a>
                            <?php endif; ?>
                            <?php if(!empty($b->content)): ?>
                                <p class="card-text mt-2" style="white-space: pre-wrap"><?php echo e($b->content); ?></p>
                            <?php endif; ?>

                            <div class="d-flex justify-content-end mt-3">
                                <form action="<?php echo e(route('block.destroy', $b->id)); ?>" method="POST" class="me-2">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-danger">
                                        <i class="bi bi-trash"></i> Удалить
                                    </button>
                                </form>
                                <a href="<?php echo e(route('block.edit', $b->id)); ?>" class="btn btn-sm btn-info">
                                    <i class="bi bi-pencil-square"></i> Редактировать
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <div class="alert alert-secondary text-center">
                    Выберите тему слева, чтобы увидеть блоки
                </div>
            <?php endif; ?>
            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\OSPanel\home\larabook\resources\views/topic/index.blade.php ENDPATH**/ ?>