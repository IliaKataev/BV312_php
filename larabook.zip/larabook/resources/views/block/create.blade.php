@extends('master')


@section('menu')
    @parent
@endsection

@section('content')
<div class="container mt-4">
        <div class="row mb-3">
            <div class="alert alert-info text-center w-100">
                {{ $page }}
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6 mx-auto">
            {{--успех--}}
            @if(session('success'))
                <div class="alert alert-success text-center">
                    {{ session('success') }}
                </div>
            @endif
            @if ($errors->any())
                <div class="alert alert-danger text-center">
                    <ul class="mb-0">
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif
        </div>
    </div>

    <form action="{{ action('App\Http\Controllers\BlockController@store') }}" method="POST" enctype="multipart/form-data" class="mt-4">
        {{-- Выбор темы select --}}
        @csrf
        <div class="mb-3 row align-items-center">
            <label for="topicid" class="col-md-2 col-form-label">Выберите тему</label>
            <div class="col-md-8">
                <select name="topicid" id="topicid" class="form-select">
                    <option value="">Выберите тему</option>
                    @foreach ($topics as $id => $topicname)
                        <option value="{{ $id }}">{{ $topicname }}</option>
                    @endforeach
                </select>
            </div>
            <div class="col-md-2">
                <a href="{{ url('topic/create') }}" class="btn btn-info w-100">Добавить тему</a>
            </div>
        </div>
        {{-- Изображение file --}}
        <div class="mb-4 row">
            <label for="imagepath" class="col-md-2 col-form-label">Картинка блока</label>
            <div class="col-md-10">
                <input type="file" name="imagepath" id="imagepath"
                    class="form-control @error('imagepath') is-invalid @enderror">
                @error('imagepath')
                    <div class="invalid-feedback">{{ $message }}</div>
                @enderror
            </div>
        </div>
        {{-- Контент textarea --}}
        <div class="mb-3 row">
            <label for="content" class="col-md-2 col-form-label">Содержимое блока</label>
            <div class="col-md-10">
                <textarea name="content" id="content"
                    class="form-control @error('content') is-invalid @enderror"
                    placeholder="Введите текст...">{{ old('content') }}</textarea>
                @error('content')
                    <div class="invalid-feedback">{{ $message }}</div>
                @enderror
            </div>
        </div>
        {{-- Заголовок блока text --}}
        <div class="mb-3 row">
            <label for="title" class="col-md-2 col-form-label">Тайтл блока</label>
            <div class="col-md-10">
                <input type="text" name="title" id="title"
                    value="{{ old('title') }}"
                    class="form-control @error('title') is-invalid @enderror"
                    placeholder="Введите название блока">
                @error('title')
                    <div class="invalid-feedback">{{ $message }}</div>
                @enderror
            </div>
        </div>
        <div class="text-center">
            <button type="submit" class="btn btn-success w-50">Добавить блок</button>
        </div>
    </form>
</div>
@endsection