@extends('master')


@section('menu')
    @parent
@endsection

@section('content')


<div class="container mt-4">
        <div class="row mb-3">
            <div class="alert alert-info text-center w-100">
                {{ $page }}
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6 mx-auto">
            {{--успех--}}
            @if(session('success'))
                <div class="alert alert-success text-center">
                    {{ session('success') }}
                </div>
            @endif
            @if ($errors->any())
                <div class="alert alert-danger text-center">
                    <ul class="mb-0">
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif
        </div>
    </div>

    <form action="{{ action('App\Http\Controllers\BlockController@store') }}" method="POST" enctype="multipart/form-data" class="mt-4">
        {{-- Выбор темы select --}}
        {{-- Изображение file --}}
        {{-- Контент textarea --}}
        {{-- Заголовок блока text --}}
    </form>
</div>


@endsection