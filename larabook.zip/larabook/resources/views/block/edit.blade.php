@extends('master')
@section('menu')
 @parent
@endsection

@section('content')
    Hello from edit
@endsection