@extends('master')

@section('title', 'Page Title')

@section('menu')
    @parent
@endsection

@section('content')
    <div class="container mt-4">
        <div class="row mb-3">
            <div class="alert alert-info text-center w-100">
                {{ $page }}
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6 mx-auto">
            {{--успех--}}
            @if(session('success'))
                <div class="alert alert-success text-center">
                    {{ session('success') }}
                </div>
            @endif
            @if ($errors->any())
                <div class="alert alert-danger text-center">
                    <ul class="mb-0">
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif
        </div>
    </div>

    <div class="row">
        <div class="col-md-6 mx-auto">
            <form action="{{ route('topic.store') }}" method="POST">
                @csrf
                <div class="mb-3">
                    <label for="topicname" class="form-label">Topic name</label>
                    <input type="text" name="topicname" id="topicname"
                        placeholder="Введите название заголовка" class="form-control 
                        @error('topicname') is-invalid @enderror">
                    @error('topicname')
                        <div class="invalid-feedback">
                            {{ $message }}
                        </div>
                    @enderror
                </div>
                <button type="submit" class="btn btn-success w-100">Добавить</button>
            </form>
        </div>

    </div>

@endsection
