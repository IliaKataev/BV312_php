<?php
use App\Http\Controllers\TopicController;
use App\Http\Controllers\BlockController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('master');
});



Route::resource('topic', TopicController::class);
Route::resource('block', BlockController::class);
