<form action="index.php?page=1" method="post" class="container my-4">
    <div class="row mb-4">
        <div class="col-md-4 ms-auto">
            <select class="form-select" name="catid" onchange="getItemsCat(this.value)">
                <option value="0">Все категории...</option>
                <?php 
                $pdo = Tools::connect();
                $ps = $pdo->prepare("SELECT * FROM Categories");
                $ps -> execute();
                while($row= $ps -> fetch()){
                    echo '<option  value="' . $row['id'] . '">' . htmlspecialchars($row['category']) . '</option>';
                }
                ?>
            </select>
        </div>
    </div>
    <div class="row g-4" id="result">
        <?php 
        $items = Item::GetItems();
        if($items && count($items) > 0){
            foreach ($items as $item){
                $item->Draw();
            }
        } else {
            echo '
                <div class="col-12 text-center py-5">
                    <div class="alert alert-warning shadow-sm w-50 mx-auto">
                        Товары не найдены
                    </div>
                </div>
            ';
        }
        ?>
    </div>

</form>
<script>
    function getItemsCat(cat){
        if(cat == ''){
            document.getElementById('resutl').innerHTML='';
        }

        if(window.XMLHttpRequest){
            ao = new XMLHttpRequest();
        } else
            ao = new ActiveXObject('Microsoft.XMLHTTP');

        ao.onreadystatechange = function(){
            if(ao.readyState == 4 & ao.status == 200){
                document.getElementById('result').innerHTML = ao.responseText;
            }
        }

        ao.open('post', 'pages/lists.php', true);
        ao.setRequestHeader('Content-type', 'application/x-www-form-urlencoded')
        ao.send('cat='+cat);
    }

    function createCookie(uname, id){
        var date = new Date(new Date().getTime() + 60 * 1000 * 30);
        document.cookie = uname + "="+ id + "; path=/; expires="+date.toUTCString();
        console.log("Cookie", uname+ "="+ id);
    }
</script>