<?php 


class Tools{
    static function connect($host = 'MySQL-8.4',$user = 'root',$pass = '123456',$dbname = 'shop'){
            try{
                $dsn = "mysql:host=$host;dbname=$dbname;charset=utf8";
                $pdo = new PDO($dsn, $user, $pass);
                $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                return $pdo;
            }
            catch(PDOException $e){
                die("Connection failed: "  . $e->getMessage());
            }
    }

    static function register($name, $pass, $imagepath){
        $name = trim(htmlspecialchars($name));
    $pass = trim(htmlspecialchars($pass));
    $imagepath = trim(htmlspecialchars($imagepath));

    if($name == "" || $pass == ""){
        echo "<h3><span class='color:red;'>Заполните все поля!</span></h3>";
        return false;
    }

    if(strlen($name) < 3 || strlen($name) > 30 
    || strlen($pass) < 3 || strlen($pass) > 30){
        echo "<h3><span class='color:red;'>Длина строки должна быть от 3 до 30 символов</span></h3>";
        return false;
    }

    Tools::connect();
    $customer=new Customer($name, $pass, $imagepath);
    $err=$customer->intoDb();
    if($err){
        if($err==1062)
            echo "<h3><span class='color:red;'>Логин уже занят</span></h3>";
        else
            echo "<h3><span class='color:red;'>Ошибка. Код" .$err. "!</span></h3>";
        return false;
    }
    return true;

    }
}

class Customer{
    protected $id;
    protected $login;
    protected $pass;
    protected $roleid;
    protected $discount;
    protected $total;
    protected $imagepath;

    function __construct($login, $pass, $imagepath, $id=0){
        $this->login=$login;
        $this->pass=$pass;
        $this->imagepath=$imagepath;
        $this->id=$id;
        $this->total=0;
        $this->discount=0;
        $this->roleid=2;

    }

    function intoDb(){
        try{
            $pdo=Tools::connect();
            $ps=$pdo->prepare("INSERT INTO Customers (login, pass, roleid, discount, total, imagepath)
            VALUES (:login, :pass, :roleid, :discount,:total,:imagepath)");
            $ps->execute([
                ':login' => $this->login,
                ':pass' => $this->pass,
                ':roleid' => $this->roleid ?? 2,
                ':discount' => $this->discount ?? 0,
                ':total' => $this->total ?? 0,
                ':imagepath' => $this->imagepath,
            ]);
            
        } catch(PDOException $e){
            $err=$e->getMessage();
            if(substr($err,0,strrpos($err,":"))==
            'SQLSTATE[23000]:
            Integrity constraint violation')
            return 1062;
            else
            return $e->getMessage();
        }
    }
    static function fromDb($id){
        $customer=null;
        try{
            $pdo=Tools::connect();
            $ps=$pdo->prepare(("SELECT * FROM Customers WHERE id=?)"));
            $res=$ps->execute([$id]);
            $row=$res->fetch();
            $customer=new Customer($row['login'],$row['pass'], $row['imagepath'], $row['id']);
            return $customer;
        } catch (PDOException $e){
            echo $e->getMessage();
            return false;
        }
    }
}

class Item{
    public $id, $itemname, $catid, $pricein, $pricesale, $info, $imagepath, $rate, $action;

    function __construct($itemname, $catid, $pricein, $pricesale, $info, $imagepath, $rate=0, $action=0, $id = 0){
        $this -> id=$id;
        $this -> itemname=$itemname;
        $this -> catid=$catid;
        $this -> pricein=$pricein;
        $this -> pricesale=$pricesale;
        $this -> info=$info;
        $this -> rate=$rate;
        $this -> imagepath=$imagepath;
        $this -> action=$action;
    }

    function intoDb(){
        try{
            $pdo=Tools::connect();
            $ps=$pdo->prepare("INSERT INTO Items (itemname, catid, pricein, pricesale, info, imagepath, rate, action)
            VALUES (:itemname, :catid, :pricein, :pricesale, :info, :imagepath, :rate, :action)");
            $ps->execute([
                ':itemname' => $this->itemname,
                ':catid' => $this->catid,
                ':pricein' => $this->pricein,
                ':pricesale' => $this->pricesale,
                ':info' => $this->info,
                ':imagepath' => $this->imagepath,
                ':rate' => $this->rate,
                ':action' => $this->action,

            ]);
            
        } catch(PDOException $e){
            $err=$e->getMessage();
            if(substr($err,0,strrpos($err,":"))==
            'SQLSTATE[23000]:
            Integrity constraint violation')
            return 1062;
            else
            return $e->getMessage();
        }
    }
    static function fromDb($id){
        $customer=null;
        try{
            $pdo=Tools::connect();
            $ps=$pdo->prepare(("SELECT * FROM Items WHERE id=?)"));
            $res=$ps->execute([$id]);
            $row=$res->fetch();
            $customer=new Item($row['itemname'],$row['catid'],
            $row['pricein'],$row['pricesale'],
            $row['info'], $row['imagepath'], 
            $row['rate'],$row['action'], $row['id']);
            return $customer;
        } catch (PDOException $e){
            echo $e->getMessage();
            return false;
        }
    }

    static function GetItems($catid=0){
        $items = [];
        try{
            $pdo = Tools::connect();
            if($catid == 0){
                $ps = $pdo->prepare('SELECT * FROM Items');
                $ps->execute();
            } else {
                $ps = $pdo->prepare('SELECT * FROM Items WHERE catid = ?');
                $ps->execute([$catid]);
            }

            while($row = $ps->fetch(PDO::FETCH_ASSOC)){
                $item = new Item(
                    $row['itemname'],
                    $row['catid'],
                    $row['pricein'],
                    $row['pricesale'],
                    $row['info'],
                    $row['imagepath'],
                    isset($row['rate']) ? $row['rate'] : 0,
                    isset($row['action']) ? $row['action'] : 0,
                    isset($row['id']) ? $row['id'] : null,
                );
                $items[] = $item;
            }
            return $items;
        } catch (PDOException $e){
            echo $e->getMessage();
            return false;
        }
    }
    
    function Draw(){
        $id = htmlspecialchars($this->id);
        $name= htmlspecialchars($this->itemname);
        $info = htmlspecialchars($this->info);
        $price = htmlspecialchars(($this -> pricesale));
        $image = htmlspecialchars($this -> imagepath);
        $rate = htmlspecialchars($this->rate);

        if(!isset($_SESSION['reg']) || $_SESSION['reg'] == '')
            {
                $user = "cart_ " . $this->id;
            } else {
                $user = $_SESSION['reg'] . "_" . $this->$id;
            }


        echo <<<HTML
            <div class='col-12 col-sm-6 col-md-4 col-lg-3 mb-4'>
                <div class='card h-100 shadow-sm border-1'>
                    <div class='position-relative'>
                        <a href='pages/itemInfo.php?name=$id' target='_blank'>
                            <img src='$image'
                                class='card-img-top'
                                alt='$name'
                                style='height:200px; object-fit:cover;'>
                        </a>
                    </div>
                    <div class='card-body d-flex flex-column'>
                        <h5 class='card-title text-primary mb-2'>
                            <a href='pages/itemInfo.php?name=$id' target='_blank'
                            class='text-decoration-none text-primary fw-semibold'>
                                $name
                            </a>
                        </h5>
                        <p class='card-text text-muted small flex-grow-1'
                        style='overflow:auto; max-height:70px;'>
                            $info
                        </p>
                        <div class='d-flex justify-content-between align-items-center mt-2'>
                            <span class='fw-bold text-danger fs-5'>
                                $price руб.
                            </span>
                        </div>
                        <div class='card-footer bg-transparent border-0'>
                            <button class='btn btn-outline-success w-100 mt-2 gap-2'
                            onclick='createCookie("$user", "$id")'>
                                <i class="bi bi-cart-plus me-2"></i>Добавить в корзину
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        HTML;
    }


}




?>