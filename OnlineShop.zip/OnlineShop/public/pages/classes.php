<?php 


class Tools{
    static function connect($host = 'MySQL-8.4',$user = 'root',$pass = '123456',$dbname = 'shop'){
            try{
                $dsn = "mysql:host=$host;dbname=$dbname;charset=utf8";
                $pdo = new PDO($dsn, $user, $pass);
                $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                return $pdo;
            }
            catch(PDOException $e){
                die("Connection failed: "  . $e->getMessage());
            }
    }

    static function register($name, $pass, $imagepath){
        $name = trim(htmlspecialchars($name));
    $pass = trim(htmlspecialchars($pass));
    $imagepath = trim(htmlspecialchars($imagepath));

    if($name == "" || $pass == ""){
        echo "<h3><span class='color:red;'>Заполните все поля!</span></h3>";
        return false;
    }

    if(strlen($name) < 3 || strlen($name) > 30 
    || strlen($pass) < 3 || strlen($pass) > 30){
        echo "<h3><span class='color:red;'>Длина строки должна быть от 3 до 30 символов</span></h3>";
        return false;
    }

    Tools::connect();
    $customer=new Customer($name, $pass, $imagepath);
    $err=$customer->intoDb();
    if($err){
        if($err==1062)
            echo "<h3><span class='color:red;'>Логин уже занят</span></h3>";
        else
            echo "<h3><span class='color:red;'>Ошибка. Код" .$err. "!</span></h3>";
        return false;
    }
    return true;

    }
}

class Customer{
    protected $id;
    protected $login;
    protected $pass;
    protected $roleid;
    protected $discount;
    protected $total;
    protected $imagepath;

    function __construct($login, $pass, $imagepath, $id=0){
        $this->login=$login;
        $this->pass=$pass;
        $this->imagepath=$imagepath;
        $this->id=$id;
        $this->total=0;
        $this->discount=0;
        $this->roleid=2;

    }

    function intoDb(){
        try{
            $pdo=Tools::connect();
            $ps=$pdo->prepare("INSERT INTO Customers (login, pass, roleid, discount, total, imagepath)
            VALUES (:login, :pass, :roleid, :discount,:total,:imagepath)");
            $ps->execute([
                ':login' => $this->login,
                ':pass' => $this->pass,
                ':roleid' => $this->roleid ?? 2,
                ':discount' => $this->discount ?? 0,
                ':total' => $this->total ?? 0,
                ':imagepath' => $this->imagepath,
            ]);
            
        } catch(PDOException $e){
            $err=$e->getMessage();
            if(substr($err,0,strrpos($err,":"))==
            'SQLSTATE[23000]:
            Integrity constraint violation')
            return 1062;
            else
            return $e->getMessage();
        }
    }
    static function fromDb($id){
        $customer=null;
        try{
            $pdo=Tools::connect();
            $ps=$pdo->prepare(("SELECT * FROM Customers WHERE id=?)"));
            $res=$ps->execute([$id]);
            $row=$res->fetch();
            $customer=new Customer($row['login'],$row['pass'], $row['imagepath'], $row['id']);
            return $customer;
        } catch (PDOException $e){
            echo $e->getMessage();
            return false;
        }
    }
}

class Item{
    public $id, $itemname, $catid, $pricein, $pricesale, $info, $imagepath, $rate, $action;

    function __construct($itemname, $catid, $pricein, $pricesale, $info, $imagepath, $rate=0, $action=0, $id = 0){
        $this -> id=$id;
        $this -> itemname=$itemname;
        $this -> catid=$catid;
        $this -> pricein=$pricein;
        $this -> pricesale=$pricesale;
        $this -> info=$info;
        $this -> rate=$rate;
        $this -> imagepath=$imagepath;
        $this -> action=$action;
    }

    function intoDb(){
        try{
            $pdo=Tools::connect();
            $ps=$pdo->prepare("INSERT INTO Items (itemname, catid, pricein, pricesale, info, imagepath, rate, action)
            VALUES (:itemname, :catid, :pricein, :pricesale, :info, :imagepath, :rate, :action)");
            $ps->execute([
                ':itemname' => $this->itemname,
                ':catid' => $this->catid,
                ':pricein' => $this->pricein,
                ':pricesale' => $this->pricesale,
                ':info' => $this->info,
                ':imagepath' => $this->imagepath,
                ':rate' => $this->rate,
                ':action' => $this->action,

            ]);
            
        } catch(PDOException $e){
            $err=$e->getMessage();
            if(substr($err,0,strrpos($err,":"))==
            'SQLSTATE[23000]:
            Integrity constraint violation')
            return 1062;
            else
            return $e->getMessage();
        }
    }
    static function fromDb($id){
        $customer=null;
        try{
            $pdo=Tools::connect();
            $ps=$pdo->prepare(("SELECT * FROM Items WHERE id=?)"));
            $res=$ps->execute([$id]);
            $row=$res->fetch();
            $customer=new Item($row['itemname'],$row['catid'],
            $row['pricein'],$row['pricesale'],
            $row['info'], $row['imagepath'], 
            $row['rate'],$row['action'], $row['id']);
            return $customer;
        } catch (PDOException $e){
            echo $e->getMessage();
            return false;
        }
    }


}




?>