<?php 
$page = $page ?? 1;
?>

<nav>
    <div class="navbar navbar-expand bg-primary navbar-dark rounded-3 mb-4">
        <div class="containter d-flex flex-column align-items-center justify-content-center"> <!-- проверить класс --> 
            <a class="navbar-brand fw-bold fs-3 text-white mx-auto" href="index.php">Online shop</a>
            <ul class="navbar-nav ms-auto d-flex flex-row gap-3">
                    <li class="nav-item">
                        <a class=" nav-link <?php echo ($page == 1) ? 'active fw-bold' : 'text-light'; ?>" href="index.php?page=1">Каталог</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo ($page == 2) ? 'active fw-bold' : 'text-light'; ?>" href="index.php?page=2">Корзина</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo ($page == 3) ? 'active fw-bold' : 'text-light'; ?>" href="index.php?page=3">Регистрация</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo ($page == 4) ? 'active fw-bold' : 'text-light'; ?>" href="index.php?page=4">Панель администратора</a>
                    </li>
                </ul>
        </div>
    </div>
</nav>

