<?php 

if(!isset($_POST['addbtn'])){
?>
<div class="container mt-5 mb-5">
    <div class="card shadow-lg border-0 rounded-4">
        <div class="card-header bg-primary text-white text-center rounded-top-4">
            <h4 class="mb-0">Добавить новый товар</h4>
        </div>
        <div class="card-body p-4">
            <form action="index.php?page=4" method="post" enctype="multipart/form-data">
                <div class="mb-3">
                    <label for="catid" class="form-label fw-semibold">Категория:</label>
                        <select class="form-select" name="catid" required>
                            <?php 
                                $pdo=Tools::connect();
                                $list=$pdo->query("SELECT * FROM Categories");
                                while($row=$list->fetch()){
                                    echo '<option value="'.$row['id'].'">'.$row['category'].'</option>';
                                }
                            ?>
                        </select>
                </div>
                <div class="mb-3">
                    <label for="name">Название</label>
                    <input type="text" class="form-control" name="name">
                </div>
                <div class="row g-3 mb-3">
                    <div class="col-md-12">
                        <label for="pricein" class="form-label fw-semibold">Начальная цена и цена продажи</label>
                        <div>
                            <input type="number" class="form-control" name="pricein" placeholder="Начальная цена">
                            <input type="number" class="form-control" name="pricesale" placeholder="Цена продажи">
                        </div>   
                    </div>
                </div>
                
                
                <div class="mb-3">
                    <label class="fw-semibold form-label" for="info">Информация</label>
                    <textarea class="form-control" rows="4" name="info"></textarea>
                </div>
                <div class="mb-4">
                    <label class="fw-semibold form-label" for="imagepath">Выберите картинку</label>
                    <input type="file" class="form-control" name="imagepath">
                </div>
                <button name="addbtn" type="submit" class="btn btn-primary">Добавить</button>


            </form>
        </div>
    </div>
</div>

<?php
}
else {
    if(is_uploaded_file($_FILES['imagepath']['tmp_name'])){
        $path="images/".$_FILES['imagepath']['name'];
        move_uploaded_file($_FILES['imagepath']['tmp_name'], $path);
    }

    $catid=$_POST['catid'];
    $pricein=$_POST['pricein'];
    $pricesale=$_POST['pricesale'];
    $name=trim(htmlspecialchars($_POST['name']));
    $info=trim(htmlspecialchars($_POST['info']));

    $item=new Item($name, $catid, $pricein,
    $pricesale, $info, $path);
    $item->intoDb();

    echo '<div class="container mt-5">
            <div class="alert alert-success shadow-sm rounded-3 text-center" role="alert">
                Товар <strong>'. $name . '</strong> успешно добавлен! 
            </div>
        </div>';
}

?>