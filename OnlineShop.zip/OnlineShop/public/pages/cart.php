<?php 
echo '<form action="index.php?page=2" method="post">';

$user = '';
if(!isset($_SESSION['reg']) || $_SESSION['reg'] ==''){
    $user = 'cart';
}else {
    $user = $_SESSION['reg'];
}

$total=0;

echo '<div class="row row-cols-1 g-3">';

foreach($_COOKIE as $k => $v){
    $pos = strpos($k, "_");
    if(substr($k, 0, $pos) == $user) {
        $id = substr($k, $pos + 1);
        $id = ltrim($id, "_");
        //echo "<pre>Item id: "; echo var_dump($id); echo "</pre>";
        $item = Item::fromDb($id);
        $total += $item->pricesale;
        $item->DrawCart();
    } 
}
echo '</div>';

echo <<<HTML
    <hr class='my-4'>
    <div class='d-flex justify-content-between align-items-center'>
        <h5 class='mb-0 text-primary'>
            Итого: <span class='text-danger fw-bold'>$total ₽</span>
        </h5>
        <button type='submit' class='btn btn-success btn-lg px-4' name='suborder' onclick="eraseCookie('$user')">
            <i class="bi bi-bag-check"></i>Оформить заказ
        </button>
    </div>
HTML;
echo '</form>';

if(isset($_POST['suborder'])){
    foreach($_COOKIE as $k => $v){
        $pos = strpos($k, '_');
        if(substr($k, 0, $pos) == $user){
            $id = substr($k, $pos + 1);
            $item = Item::fromDb($id);
            $item -> Sale();
        }
    }
}
?>
<script>
    function createCookie(uname, id){
        var date = new Date(new Date().getTime() + 60 * 1000 * 30);
        document.cookie = uname + "="+ id + "; path=/; expires="+date.toUTCString();
        console.log("Cookie", uname+ "="+ id);
    }

    function eraseCookie(uname){
        const date = new Date(Date.now() - 60000);
        document.cookie = uname + "=; path=/; expires="+date.toUTCString();
        console.log('Удален куки:', uname)
    }
</script>



