<?php 
session_start();
include_once("pages/functions.php");
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;

/*
Catalog - отображение товаров, механизмы фильтрации для указания критериев выбора пользователя. + отбор товаров в корзину
Cart - корзина пользователя, в которой он может редактировать список товаров отобранных, оформлять заказ на покупку
Registration - страница регистрации
AdminForm - пункт меню администратора сайта
Reports - отчеты о работе интернет магазина



*/
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Travel Agency</title>
  <link
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
    rel="stylesheet">
  <link rel="stylesheet" href="css/style1.css">
</head>
<body>
  <div class="container mt4">
    <!-- Хэдер -->
    <div class="row mb-3">
      <header class="col-12 text-center">
        <h1>Добро пожаловать в Travel Agency</h1>
        <?php include_once("pages/login.php"); ?>
      </header>
    </div>

    <!-- Меню -->
    <div class="row mb-4">
      <nav class="col-12">
        <?php include_once('pages/menu.php') ?>
      </nav>
    </div>

    <!--Основная часть-->
    <div class="row">
      <section class="col-12">
        <?php 
        switch ($page){
          case 1:
            include_once('pages/Tours.php');
            break;
          case 2:
            include_once('pages/comments.php');
            break;
          case 3:
            include_once('pages/Registration.php');
            break;
          case 4:
            include_once('pages/Admin.php');
            break;
          default:
            echo "<h3>Страница не найдена</h3>";
        }
         ?>
      </section>
    </div>

    <div class="row mt-4">
        <footer class="col-12 text-center text-muted">
          Ilia inc &copy; <?php echo date('Y'); ?>
        </footer>
    </div>
  </div>

<script
  src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js">
</script>
</body>
</html>