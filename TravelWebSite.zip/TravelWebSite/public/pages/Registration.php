<?php

include_once('pages/functions.php');

$conn = connect();
if($conn){
    echo "<h3><span class='color:green;'>Подключение к базе успешно!</span></h3>";
    mysqli_close($conn);
} else{
    echo "<h3><span class='color:red;'>Подключиться не удалось</span></h3>";
}
?>

<h3>Форма регистрации</h3>

<?php 
if(!isset($_POST['regbtn'])){
?>
<form action="index.php?page=3" method="post">
  <div class="form-group">
    <label for="login">Логин:</label>
    <input type="text" class="form-control" name="login" required>
  </div>

  <div class="form-group">
    <label for="pass1">Пароль:</label>
    <input type="password" class="form-control" name="pass1" required>
  </div>

  <div class="form-group">
    <label for="pass2">Пароль 2х:</label>
    <input type="password" class="form-control" name="pass2" required>
  </div>

  <div class="form-group">
    <label for="email">Почта:</label>
    <input type="email" class="form-control" name="email" required>
  </div>

  <button type="submit" class="btn btn-primary" name="regbtn">Register</button>
</form>
<?php
} else {
    if($_POST['pass1'] !== $_POST['pass2']){
        echo "<h3><span class='color:red;'>Пароли не совпали. Try again</span></h3>";
    } else{
        if(register($_POST['login'], $_POST['pass1'], $_POST['email'])){
            echo "<h3><span class='color:green;'>Регистрация завершена. Пользователь добавлен!</span></h3>";
        } else{
            echo "<h3><span class='color:red;'>Регистрация провалилась. Try again</span></h3>";

        }
    }
}
?>