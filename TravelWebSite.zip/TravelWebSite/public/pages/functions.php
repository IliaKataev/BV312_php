<?php

function connect(
    $host = 'MySQL-8.4',
    $user = 'root',
    $pass = '123456',
    $dbname = 'travels'
){
    $link = mysqli_connect($host, $user, $pass, $dbname);

    if(!$link){
        die('connection error: ' . mysqli_connect_error());
    }

    mysqli_set_charset($link, 'utf8');

    return $link;
}

function register($name, $pass, $email){
    $name = trim(htmlspecialchars($name));
    $pass = trim(htmlspecialchars($pass));
    $email = trim(htmlspecialchars($email));

    if($name == "" || $pass == "" || $email == ""){
        echo "<h3><span class='color:red;'>Заполните все поля!</span></h3>";
        return false;
    }

    if(strlen($name) < 3 || strlen($name) > 30 
    || strlen($pass) < 3 || strlen($pass) > 30){
        echo "<h3><span class='color:red;'>Длина строки должна быть от 3 до 30 символов</span></h3>";
        return false;
    }

    $conn = connect();

    $stmt = mysqli_prepare($conn, "SELECT id FROM users WHERE login = ?");
    mysqli_stmt_bind_param($stmt, "s", $name);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_store_result($stmt);

    if(mysqli_stmt_num_rows($stmt) > 0){
        echo "<h3><span class='color:red;'>Логин занят</span></h3>";
        mysqli_stmt_close($stmt);
        mysqli_close($conn);
        return false;
    }

    $hash = password_hash($pass, PASSWORD_DEFAULT);

    $stmt = mysqli_prepare($conn, "INSERT INTO users (login, pass, email, roleid) VALUES (?, ?, ?, 2)");
    mysqli_stmt_bind_param($stmt, "sss", $name, $hash, $email);

    if(!mysqli_stmt_execute($stmt)){
        echo "<h3><span class='color:red;'>Ошибка БД: " . mysqli_error($conn) ."</span></h3>";
        mysqli_stmt_close($stmt);
        mysqli_close($conn);
        return false;
    }

    mysqli_stmt_close($stmt);
    mysqli_close($conn);
    echo "<h3><span class='color:green;'>Пользователь был добавлен!</span></h3>";

    return true;

}

function login($name, $pass){
    $name = trim(htmlspecialchars($name));
    $pass = trim(htmlspecialchars($pass));

    if($name == "" || $pass == ""){
        echo "<h3><span class='color:red;'>Заполните все поля!</span></h3>";
        return false;
    }

    if(strlen($name) < 3 || strlen($name) > 30 
    || strlen($pass) < 3 || strlen($pass) > 30){
        echo "<h3><span class='color:red;'>Длина строки должна быть от 3 до 30 символов</span></h3>";
        return false;
    }

    $conn = connect();

    //$sql = 'select * from users where login="' . $name . '" and pass="' . md5($pass) . '"';/////
    $stmt = mysqli_prepare($conn, "SELECT id, login, pass, roleid FROM users WHERE login = ?");
    mysqli_stmt_bind_param($stmt, "s", $name);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_bind_result($stmt, $id, $login, $hash, $roleid);

    if(mysqli_stmt_fetch($stmt)){
        var_dump($hash);
        if(password_verify($pass, $hash)){
            $_SESSION['user'] = $login;
            if($roleid == 1){
                $_SESSION['admin'] = $login;
            }
            echo '<div class="alert alert-success">Вы успешно вошли</div>';
            return true;
        } else {
            echo '<div class="alert alert-warning">Неверный пароль</div>';
        }
    } else {
        echo '<div class="alert alert-danger">Пользователь не найден</div>';
    }

    mysqli_stmt_close($stmt);
    return false;
}
?>

