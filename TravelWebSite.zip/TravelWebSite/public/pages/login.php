<?php 
include_once('pages/functions.php');

if (isset($_SESSION["user"])):
?>
    <form action="index.php<?= isset($_GET['page']) ? '?page=' . intval($_GET['page']) : ''?>" 
    method="post" class="d-flex justify-content-end align-items-center gap-2 mb-3">
        <h5 class="mb-0">
            Привет, <span class="text-primary"><?= htmlspecialchars($_SESSION['user'])?></span>
        </h5>
        <button type="submit" name="logout" class="btn btn-sm btn-secondary">Выйти</button>
    </form>

    <?php
    if(isset($_POST['logout'])){
        unset($_SESSION['user']);
        unset($_SESSION['admin']);
        header("Location: index.php");
        exit;
    }
    ?>

<?php else:
    if(isset($_POST['login_submit'])){
        if(login($_POST['login'], $_POST['pass'])){
            header("Location: index.php");
            exit;
        }
    }
?>  
    <form action="index.php<?= isset($_GET['page']) ? '?page=' . intval($_GET['page']) : ''?>" 
    method="post" class="d-flex justify-content-end align-items-center gap-2 mb-3">
        <input type="text" name="login" class="form-control form-control-sm w-auto" placeholder="Введите логин">
        <input type="password" name="pass" class="form-control form-control-sm w-auto" placeholder="Введите пароль">
        <button type="submit" name="login_submit" class="btn btn-sm btn-primary">Войти</button>
    </form>

<?php endif; ?>