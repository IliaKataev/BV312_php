<?php 
$page = $page ?? 1;
?>

<nav>
    <div class="navbar navbar-expand-lg navbar-dark bg-primary rounded-3 mb-4">
        <div class="containter-fluid"> <!-- проверить класс --> 
            <a class="navbar-brand fw-bold" href="index.php">Travel Agency</a>
            <button class="navbar-toggle" type="button" data-bs-toggle="collapse" data-bs-target="#mainNavbar"
            aria-controls="#mainNavbar" aria-expanded="false" aria-label="Toggle Navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="mainNavbar">
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link <?php echo ($page == 1) ? 'active' : ''; ?>" href="index.php?page=1">Туры</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo ($page == 2) ? 'active' : ''; ?>" href="index.php?page=2">Комментарии</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo ($page == 3) ? 'active' : ''; ?>" href="index.php?page=3">Регистрация</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo ($page == 4) ? 'active' : ''; ?>" href="index.php?page=4">Панель администратора</a>
                    </li>
                </ul>
            </div>  
        </div>
    </div>
</nav>

