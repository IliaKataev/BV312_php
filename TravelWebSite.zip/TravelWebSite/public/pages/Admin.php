<?php 
 if(!isset($_SESSION['admin'])){
    echo '<div><span style="color:red">Только для админов!!!!! Прочь!!!!! ))))</span></div>';
    exit();
 }
?>

<div class="container">
    <!-- Страны и города -->
    <div class="row mb-3">
        <div class="col-md-6">
            <!-- Секция страны -->
            <?php 
            $conn = connect();

            $sel = "select * from countries";
            $res = mysqli_query($conn, $sel);

            echo '<form action="index.php?page=4" method="post" class="p-3 border rounded shadow-sm bg-light" id="formcountry">';
            echo '<h5 class="mb-3">Список стран</h5>';

            echo '<table class="table table-striped table-bordered align-middle">';
            echo '<thead class=table-primary>
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col">Страна</th>
                        <th scope="col">Выбрать</th>
                    </tr>
                </thead>';
            
            echo '<tbody>';

            while($row = mysqli_fetch_array($res,MYSQLI_NUM )){
                echo '<tr>';
                echo '<td>' . htmlspecialchars($row[0]) . '</td>';
                echo '<td>' . htmlspecialchars($row[1]) . '</td>';
                echo '<td><input class="form-check-input" type="checkbox" name="cb' . $row[0] . '"></td';
                echo '</tr>';
            }

            echo '</tbody>';
            echo '</table>';
            
            //кнопка и поле для добавления

            echo '<div class="input-group mb-3">';
            echo '  <input type="text" name="country" class="form-control" placeholder="Введите новую страну">';
            echo '  <button type="submit" name="addcountry" class="btn btn-success">Добавить</button>';
            echo '  <button type="submit" name="deletecountry" class="btn btn-danger">Удалить</button>';
            echo '</div>';

            echo '</form>';

            if (isset($_POST['addcountry'])) {
                $country = trim(htmlspecialchars($_POST['country']));
                if($country == ""){
                    echo '<div class="alert alert-warning">Введите название страны!</div>';
                } else {
                    $stmt = mysqli_prepare($conn, "insert into countries (country) VALUES (?)");
                    mysqli_stmt_bind_param($stmt, "s", $country );

                    if(mysqli_stmt_execute($stmt)){
                        echo '<div class="alert alert-success">Страна добавлена!</div>';
                    } else {
                        echo '<div class="alert alert-danger">Страна не добавлена!</div>';
                    }

                    mysqli_stmt_close($stmt);
                    echo '<script>window.location=document.URL;</script>';
                }
                    
            }

            if(isset($_POST['deletecountry'])){
                foreach($_POST as $k => $v){
                    if(substr($k, 0, 2) == "cb"){
                        $idc = intval(substr($k, 2));
                        $stmt = mysqli_prepare($conn, 'delete from countries where id = ?');
                        mysqli_stmt_bind_param($stmt, "i", $idc);
                        mysqli_stmt_execute($stmt);
                        mysqli_stmt_close($stmt);
                    }
                }
                echo '<div class="alert alert-info">Страна удалена!</div>';
                echo '<script>window.location=document.URL;</script>';

            }

            mysqli_free_result($res);
            mysqli_close($conn);
            ?>
        </div>
        <div class="col-md-6">
            <!-- Секция города -->
            <?php 
            $conn = connect();

            $sel = " SELECT ci.id, ci.city, co.country
                        FROM cities ci
                        JOIN countries co ON ci.countryid = co.id";
            $cities = mysqli_query($conn, $sel);
            $countries = mysqli_query($conn, "select id, country from countries order by country");
            ?>

            <form action="index.php?page=4" method="post" class="p-3 border rounded shadow-sm bg-light" id="formcity">
                <h5 class="mb-3">Список городов</h5>
                <div class="table-responsive mb-3">
                    <table class="table table-striped table-bordered align-middle">
                        <thead class="table-primary">
                            <tr>
                                <th>ID</th>
                                <th>Город</th>
                                <th>Страна</th>
                                <th>Выбрать</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($row = mysqli_fetch_assoc($cities)): ?>
                                <tr>
                                    <td><?= htmlspecialchars($row['id'])?></td>
                                    <td><?= htmlspecialchars($row['city'])?></td>
                                    <td><?= htmlspecialchars($row['country'])?></td>
                                    <td><input type="checkbox" class="form-check-input" name="ci<?= $row['id']?>"></td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
                <div class="input-group mb-3">
                    <label class="input-group-text" for="countryname">Страна</label>
                    <select name="countryname" id="countryname" class="form-select">
                        <?php while ($row = mysqli_fetch_assoc($countries)):?>
                            <option value="<?= $row['id'] ?>"><?= htmlspecialchars($row['country']) ?></option>
                        <?php endwhile; ?>
                    </select>
                    <input type="text" name="city" class="form-control" placeholder="Введите город">
                    <button type="submit" name="addcity" class="btn btn-success">Добавить</button>
                    <button type="submit" name="deletecity" class="btn btn-danger">Удалить</button>
                </div>

            </form>

            <?php 
            
            if(isset($_POST['addcity'])){
                $conn = connect();
                $city = trim(htmlspecialchars($_POST['city']));
                $countryid = (int)$_POST['countryname'];

                if($city == ""){
                    echo '<div class="alert alert-warning">Введите название города!</div>';
                } else {
                    $check = mysqli_prepare($conn, "select id from cities where city = ? AND countryid = ?");
                    mysqli_stmt_bind_param($check, "si", $city, $countryid);
                    mysqli_stmt_execute($check);
                    mysqli_stmt_store_result($check);

                    if(mysqli_stmt_num_rows($check) > 0){
                        echo '<div class="alert alert-warning">Такой город уже существует!</div>';
                    } else {
                        mysqli_stmt_close($check);

                        $stmt = mysqli_prepare($conn, "insert into cities (city, countryid) values (?, ?)");
                        mysqli_stmt_bind_param($stmt, "si", $city, $countryid);

                        if(mysqli_stmt_execute($stmt)){
                            echo '<div class="alert alert-success">Город добавлен!</div>';
                            echo '<script>window.location=document.URL;</script>';
                        } else {
                            echo '<div class="alert alert-warning">Ошибка при добавлении города!</div>';
                        }
                        mysqli_stmt_close($stmt);
                    }
                    mysqli_close($conn);
                }
            }

            if(isset($_POST['deletecity'])){
                foreach($_POST as $k => $v){
                    if(substr($k, 0, 2) == "ci"){
                        $idc = intval(substr($k, 2));
                        $stmt = mysqli_prepare($conn, 'delete from cities where id = ?');
                        mysqli_stmt_bind_param($stmt, "i", $idc);
                        mysqli_stmt_execute($stmt);
                        mysqli_stmt_close($stmt);
                    }
                }
                mysqli_close($conn);
                echo '<div class="alert alert-info">Город удален!</div>';
                echo '<script>window.location=document.URL;</script>';
            }


            mysqli_free_result($cities);
            mysqli_free_result($countries);
            ?>
        </div>
    </div>

    <hr>

    <!-- Отели и картинки -->
    <div class="row mb-3">
        <div class="col-md-6">
            <!-- Секция отелей -->
            <?php 

            $sql = "
                SELECT ho.id, ho.hotel, ho.stars, ho.info, ci.city, co.country
                FROM hotels ho
                JOIN cities ci ON ho.cityid = ci.id
                JOIN countries co ON ho.countryid = co.id
            ";

            $res = mysqli_query($conn, $sql);
            ?>

            <form action="index.php?page=4" method="post" class="p-3 border rounded shadow-sm bg-light" id="formhotel">
                <h5 class="mb-3">Список отелей</h5>
                <table class="table table-striped table-bordered align-middle">
                    <thead class="table-primary">
                        <tr>
                            <th>ID</th>
                            <th>Город - Страна</th>
                            <th>Название</th>
                            <th>Звезд</th>
                            <th>Выбрать</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($row = mysqli_fetch_assoc($res)): ?>
                            <tr>
                                <td><?= htmlspecialchars($row['id'])?></td>
                                <td><?= htmlspecialchars($row['city'] . ' - ' . $row['country'])?></td>
                                <td><?= htmlspecialchars($row['hotel'])?></td>
                                <td><?= htmlspecialchars($row['stars'])?></td>
                                <td><input type="checkbox" class="form-check-input" name="hb<?=$row['id'] ?>"></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>

                <?php 
                mysqli_free_result($res);
                $sql = "
                    SELECT ci.id as cityid, ci.city, co.country, co.id as countryid
                    FROM cities ci
                    JOIN countries co ON ci.countryid = co.id
                ";

                $res = mysqli_query($conn, $sql);          
                ?>

                <div class="row g-3 align-items-end mb-3">
                    <div class="col-mb-4">
                        <label for="hcity" class="form-label">Город</label>
                        <select name="hcity" id="hcity" class="form-select">
                            <?php while($row = mysqli_fetch_assoc($res)): ?>
                                <option value="<?= htmlspecialchars($row['cityid'])?>">
                                    <?= htmlspecialchars($row['city'] . ' - ' . $row['country'])?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="col-mb-4">
                        <label for="hotel" class="form-label">Название</label>
                        <input type="text" name="hotel" id="hotel" class="form-control" placeholder="Введите название">
                    </div>
                    <div class="col-mb-2">
                        <label for="stars" class="form-label">Звезд</label>
                        <input type="text" name="stars" id="stars" class="form-control" placeholder="Введите название">
                    </div>
                    <div class="col-mb-2">
                        <label for="cost" class="form-label">Цена</label>
                        <input type="text" name="cost" id="cost" class="form-control" placeholder="Введите название">
                    </div>
                    <div class="col-mb-3">
                        <label for="info" class="form-label">Описание</label>
                        <textarea name="info" id="info" class="form-control" rows="3" placeholder="Описание отеля"></textarea>
                    </div>

                    <div class="d-flex gap-2">
                        <button type="submit" name="addhotel" class="btn btn-success">Добавить</button>
                        <button type="submit" name="deletehotel" class="btn btn-danger">Удалить</button>
                    </div>
                </div>
            </form>

            <?php

            if(isset($_POST['addhotel'])){
                $hotel = trim(htmlspecialchars($_POST['hotel']));
                $stars = intval(trim($_POST['stars']));
                $cost = intval(trim($_POST['cost']));
                $info = trim(htmlspecialchars($_POST['info']));
                $cityid = intval($_POST['hcity']);

                if($hotel == "" || $cost == 0 || $stars == 0){
                    echo '<div class="alert alert-warning">Заполните все поля!</div>';
                } else{
                    $query = "SELECT countryid FROM cities WHERE id = ?";
                    $stmt = mysqli_prepare($conn, $query);
                    mysqli_stmt_bind_param($stmt, "i", $cityid);
                    mysqli_execute($stmt);
                    mysqli_stmt_bind_result($stmt, $countryid);
                    mysqli_stmt_fetch($stmt);
                    mysqli_stmt_close($stmt);

                    $stmt = mysqli_prepare($conn, "
                        INSERT INTO hotels (hotel, cityid, countryid, stars, cost, info)
                        VALUES (?, ?, ?, ?, ?, ?)
                    ");
                    mysqli_stmt_bind_param($stmt, "siiiis", $hotel, $cityid, $countryid, $stars, $cost, $info);

                    if(mysqli_execute($stmt)){
                        echo '<div class="alert alert-success">Отель успешно добавлен!</div>';
                        echo '<meta http-equiv="refresh" content="0">';
                    } else {
                        echo '<div class=alert alert-danger>Ошибка при добавлении отеля: '. mysqli_error($conn) . '</div>';
                    }
                }
            }

            if(isset($_POST['deletehotel'])){
                foreach($_POST as $k => $v){
                    if(substr($k, 0, 2) == "hb"){
                        $idc = intval(substr($k, 2));
                        $stmt = mysqli_prepare($conn, 'delete from hotels where id = ?');
                        mysqli_stmt_bind_param($stmt, "i", $idc);
                        mysqli_stmt_execute($stmt);
                        mysqli_stmt_close($stmt);
                    }
                }
                mysqli_close($conn);
                echo '<div class="alert alert-info">Отель удален!</div>';
                echo '<script>window.location=document.URL;</script>';
            }
            
            
            mysqli_free_result($res);
            ?>
            
        </div>
        <div class="col-md-6">
            <!-- Секция картинок -->
            <?php 
            $sql = "
                SELECT ho.id, co.country, ci.city, ho.hotel
                FROM countries co
                JOIN hotels ho ON co.id = ho.countryid
                JOIN cities ci ON ci.id = ho.cityid
                ORDER BY co.country
            ";

            $res = mysqli_query($conn,$sql);
            ?>

            <form action="index.php?page=4" method="post" class="p-3 border rounded shadow-sm bg-light input-group" id="formimages" enctype="multipart/form-data">
                <h5 class="mb-3">Добавить изображение отеля</h5>
                <div class="row g-3 mb-3 align-items-end">
                    <div class="col-md-6">
                        <label for="hotelid" class="form-label">Выберите отель</label>
                        <select name="hotelid" id="hotelid" class="form-select" required>
                            <option value="" disabled selected>Выберите отель</option>
                            <?php while($row=mysqli_fetch_array($res, MYSQLI_NUM)): ?>
                                <option value="<?=htmlspecialchars($row[0])?>">
                                    <?= htmlspecialchars($row[1])?> - <?=htmlspecialchars($row[2]) ?> - <?=htmlspecialchars($row[3]) ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label" for="file">Выберите изображение</label>
                        <input type="file" name="file[]" id="file" class="form-control" multiple accept="image/*" required>
                    </div>
                </div>
                <div class="d-flex gap-2">
                    <button type="submit" name="addimage" class="btn btn-success">Загрузить</button>
                </div>
            </form>

            <?php
            if(isset($_POST['addimage'])){
                $uploadDir = "images/";
                $hotelid = intval($_POST['hotelid']);

                if(!is_dir($uploadDir)){
                    mkdir($uploadDir, 0777, false);
                }

                foreach($_FILES['file']['name'] as $k => $filename){
                    $tmpName = $_FILES['file']['tmp_name'][$k];
                    $error = $_FILES['file']['error'][$k];

                    if($error !== UPLOAD_ERR_OK){
                        echo "<div class='alert alert-warning'>Ошибка загрузки файла $filename</div>";
                    }

                    $safeName = basename($filename);
                    $targetPath = $uploadDir . $safeName;

                    if(move_uploaded_file($tmpName, $targetPath)){
                        $stmt = mysqli_prepare($conn, "INSERT INTO images (hotelid, imagepath) VALUES (?, ?)");
                        mysqli_stmt_bind_param($stmt, "is", $hotelid, $targetPath);
                        mysqli_stmt_execute($stmt);
                        mysqli_stmt_close($stmt);
                    } else {
                        echo "<div class='alert alert-warning'>Ошибка при сохранении файла: $filename</div>";
                    }
                }
                
               
                echo "<div class='alert alert-success'>Файл загружен</div>";
                echo "<meta http-equiv='refresh' content='0'>";
            }
            mysqli_close($conn);
            ?>
        </div>
    </div>


</div>