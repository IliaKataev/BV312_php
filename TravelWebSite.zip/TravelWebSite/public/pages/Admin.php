<div class="container">
    <!-- Страны и города -->
    <div class="row mb-3">
        <div class="col-md-6">
            <!-- Секция страны -->
            <?php 
            $conn = connect();

            $sel = "select * from countries";
            $res = mysqli_query($conn, $sel);

            echo '<form action="index.php?page=4" method="post" class="p-3 border rounded shadow-sm bg-light" id="formcountry">';
            echo '<h5 class="mb-3">Список стран</h5>';

            echo '<table class="table table-striped table-bordered align-middle">';
            echo '<thead class=table-primary>
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col">Страна</th>
                        <th scope="col">Выбрать</th>
                    </tr>
                </thead>';
            
            echo '<tbody>';

            while($row = mysqli_fetch_array($res,MYSQLI_NUM )){
                echo '<tr>';
                echo '<td>' . htmlspecialchars($row[0]) . '</td>';
                echo '<td>' . htmlspecialchars($row[1]) . '</td>';
                echo '<td><input class="form-check-input" type="checkbox" name="cb' . $row[0] . '"></td';
                echo '</tr>';
            }

            echo '</tbody>';
            echo '</table>';
            
            //кнопка и поле для добавления

            echo '<div class="input-group mb-3">';
            echo '  <input type="text" name="country" class="form-control" placeholder="Введите новую страну">';
            echo '  <button type="submit" name="addcountry" class="btn btn-success">Добавить</button>';
            echo '  <button type="submit" name="deletecountry" class="btn btn-danger">Удалить</button>';
            echo '</div>';

            echo '</form>';

            if (isset($_POST['addcountry'])) {
                $country = trim(htmlspecialchars($_POST['country']));
                if($country == ""){
                    echo '<div class="alert alert-warning">Введите название страны!</div>';
                } else {
                    $stmt = mysqli_prepare($conn, "insert into countries (country) VALUES (?)");
                    mysqli_stmt_bind_param($stmt, "s", $country );

                    if(mysqli_stmt_execute($stmt)){
                        echo '<div class="alert alert-success">Страна добавлена!</div>';
                    } else {
                        echo '<div class="alert alert-danger">Страна не добавлена!</div>';
                    }

                    mysqli_stmt_close($stmt);
                    echo '<script>window.location=document.URL;</script>';
                }
                    
            }

            if(isset($_POST['deletecountry'])){
                foreach($_POST as $k => $v){
                    if(substr($k, 0, 2) == "cb"){
                        $idc = intval(substr($k, 2));
                        $stmt = mysqli_prepare($conn, 'delete from countries where id = ?');
                        mysqli_stmt_bind_param($stmt, "i", $idc);
                        mysqli_stmt_execute($stmt);
                        mysqli_stmt_close($stmt);
                    }
                }
                echo '<div class="alert alert-info">Страна удалена!</div>';
                echo '<script>window.location=document.URL;</script>';

            }

            mysqli_free_result($res);
            mysqli_close($conn);
            ?>
        </div>
        <div class="col-md-6">
            <!-- Секция города -->
            <?php 
            $conn = connect();

            $sel = " SELECT ci.id, ci.city, co.country
                        FROM cities ci
                        JOIN countries co ON ci.countryid = co.id";
            $cities = mysqli_query($conn, $sel);
            $countries = mysqli_query($conn, "select id, country from countries order by country");
            ?>

            <form action="index.php?page=4" method="post" class="mt-4" id="formcity">
                <div class="table-responsive mb-3">
                    <table class="table table striped align-middle">
                        <thead class="table-dark">
                            <tr>
                                <th>ID</th>
                                <th>Город</th>
                                <th>Страна</th>
                                <th>Выбрать</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($row = mysqli_fetch_assoc($cities)): ?>
                                <tr>
                                    <td><?= htmlspecialchars($row['id'])?></td>
                                    <td><?= htmlspecialchars($row['city'])?></td>
                                    <td><?= htmlspecialchars($row['country'])?></td>
                                    <td><input type="checkbox" class="form-check-input" name="ci<?= $row['id']?>"></td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
                <div class="input-group mb-3">
                    <label class="input-group-text" for="countryname">Страна</label>
                    <select name="countryname" id="countryname" class="form-select">
                        <?php while ($row = mysqli_fetch_assoc($countries)):?>
                            <option value="<?= $row['id'] ?>"><?= htmlspecialchars($row['country']) ?></option>
                        <?php endwhile; ?>
                    </select>
                    <input type="text" name="city" class="form-control" placeholder="Введите город">
                    <button type="submit" name="addcity" class="btn btn-success">Добавить</button>
                    <button type="submit" name="deletecity" class="btn btn-danger">Удалить</button>
                </div>

            </form>

            <?php 
            
            if(isset($_POST['addcity'])){
                $conn = connect();
                $city = trim(htmlspecialchars($_POST['city']));
                $countryid = (int)$_POST['countryname'];

                if($city == ""){
                    echo '<div class="alert alert-warning">Введите название города!</div>';
                } else {
                    $check = mysqli_prepare($conn, "select id from cities where city = ? AND countryid = ?");
                    mysqli_stmt_bind_param($check, "si", $city, $countryid);
                    mysqli_stmt_execute($check);
                    mysqli_stmt_store_result($check);

                    if(mysqli_stmt_num_rows($check) > 0){
                        echo '<div class="alert alert-warning">Такой город уже существует!</div>';
                    } else {
                        mysqli_stmt_close($check);

                        $stmt = mysqli_prepare($conn, "insert into cities (city, countryid) values (?, ?)");
                        mysqli_stmt_bind_param($stmt, "si", $city, $countryid);

                        if(mysqli_stmt_execute($stmt)){
                            echo '<div class="alert alert-success">Город добавлен!</div>';
                            echo '<script>window.location=document.URL;</script>';
                        } else {
                            echo '<div class="alert alert-warning">Ошибка при добавлении города!</div>';
                        }
                        mysqli_stmt_close($stmt);
                    }
                    mysqli_close($conn);
                }
            }

            if(isset($_POST['deletecity'])){
                $conn = connect();
                foreach($_POST as $k => $v){
                    if(substr($k, 0, 2) == "ci"){
                        $idc = intval(substr($k, 2));
                        $stmt = mysqli_prepare($conn, 'delete from cities where id = ?');
                        mysqli_stmt_bind_param($stmt, "i", $idc);
                        mysqli_stmt_execute($stmt);
                        mysqli_stmt_close($stmt);
                    }
                }
                mysqli_close($conn);
                echo '<div class="alert alert-info">Город удален!</div>';
                echo '<script>window.location=document.URL;</script>';
            }


            mysqli_free_result($cities);
            mysqli_free_result($countries);
            ?>
        </div>
    </div>

    <hr>

    <!-- Отели и картинки -->
    <div class="row mb-3">
        <div class="col-md-6">
            <!-- Секция отелей -->3333333
        </div>
        <div class="col-md-6">
            <!-- Секция картинок -->44444
        </div>
    </div>


</div>