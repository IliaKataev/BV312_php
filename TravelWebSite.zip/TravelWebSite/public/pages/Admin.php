<div class="container">
    <!-- Страны и города -->
    <div class="row mb-3">
        <div class="col-md-6">
            <!-- Секция страны -->111111
        </div>
        <div class="col-md-6">
            <!-- Секция города -->222222
        </div>
    </div>

    <hr>

    <!-- Отели и картинки -->
    <div class="row mb-3">
        <div class="col-md-6">
            <!-- Секция отелей -->3333333
        </div>
        <div class="col-md-6">
            <!-- Секция картинок -->44444
        </div>
    </div>


</div>